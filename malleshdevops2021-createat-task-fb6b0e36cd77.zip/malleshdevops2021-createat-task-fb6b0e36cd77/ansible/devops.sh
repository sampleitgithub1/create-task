#! /bin/bash

echo "devops"
sleep 300
echo "sleep completed"
